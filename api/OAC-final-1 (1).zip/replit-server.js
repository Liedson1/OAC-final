const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

app.post('/dados-do-wokwi', async (req, res) => {
  const { temperatura, umidade } = req.body;
  console.log('Dados recebidos do Wokwi - Temperatura:', temperatura, 'Umidade:', umidade);

  // Envie os dados para o Vercel usando uma solicitação POST
  const vercelApiUrl = 'https://oac-final-d6biukp81-liedsons-projects.vercel.app/api/receber-dados'; // Substitua pelo URL da sua API Vercel
  const data = { temperatura, umidade };

  try {
    const response = await fetch(vercelApiUrl, {
      method: 'POST',
      body: JSON.stringify(data),
      headers: { 'Content-Type': 'application/json' },
    });

    if (response.ok) {
      console.log('Dados enviados com sucesso para o Vercel.');
      res.status(200).send('Dados recebidos com sucesso.');
    } else {
      console.error('Falha ao enviar dados para o Vercel:', response.statusText);
      res.status(500).send('Erro ao enviar dados para o Vercel.');
    }
  } catch (error) {
    console.error('Erro ao enviar dados para o Vercel:', error);
    res.status(500).send('Erro ao enviar dados para o Vercel.');
  }
});

app.listen(PORT, () => {
  console.log(`Servidor Replit está ouvindo na porta ${PORT}`);
});
